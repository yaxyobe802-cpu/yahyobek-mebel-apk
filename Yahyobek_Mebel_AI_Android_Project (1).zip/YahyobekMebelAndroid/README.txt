Yahyobek Mebel AI Android project

This project wraps the included index.html in an Android WebView and keeps the app content on-device.

To build an APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be under app/build/outputs/apk/debug/app-debug.apk.

This ZIP is Android project source, not a prebuilt APK. It has not been compiled or tested on a device in this environment.
